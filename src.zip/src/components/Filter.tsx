import React, { useState } from "react";
import { useDispatch } from "react-redux"
import { GetOrders } from "../actions/OrderAction";
import { OrderFilter } from '../actions/OrderActionTypes'
import {useSelector} from "react-redux"
import {RootStore} from "../Store";
import {orderStatusTransformFromAPI, orderTransformFromAPI} from '../utinities/orderTransform'
const Filter = () => {
    const [keyword, setKeyWord ] = useState('')
    const [activeFilter, setActiveFilter ] = useState('')
    const dispatch = useDispatch()
    const appliedFilters = useSelector((state:RootStore) => state.order).appliedFilters
    const test = useSelector((state:RootStore) => state.order).orders
    const activeButton = (id: string, appliedFilters: Array<OrderFilter>) => {
        const activeButton = appliedFilters.filter((filter) => {
            return filter.filterName === id
        })
        return activeButton
    }
    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault()
        const debug = appliedFilters && activeButton(event.currentTarget.id, appliedFilters)
        if (debug && debug.length > 0) {
            setActiveFilter('active')
        }
        const filters: Array<OrderFilter> = [{
            filterName: event.currentTarget.id,
            filterValue: keyword
        }]
        dispatch(GetOrders(filters))
    }
    return (
        <div className="order__filter">
            <input type="text" className="form-control my-4" placeholder="ID" aria-label="ID"
                   onChange={(event) => setKeyWord(event.target.value)}
                   aria-describedby="basic-addon1"/>
            <div className="form-floating">
                {activeFilter}
                <button type="button"
                        className={"btn btn-outline-primary btn-lg mx-3"
                        }
                        id="filter_id"
                        onClick={handleClick}>ID</button>
                <button
                    type="button"
                    className="btn btn-outline-primary btn-lg mx-3"
                    id="filter_status"
                    onClick={handleClick}
                >Status</button>
                <button type="button" className="btn btn-outline-primary btn-lg mx-3" id="filter_customer_name"
                        onClick={handleClick}>Customer name</button>
                <button type="button" className="btn btn-outline-primary btn-lg mx-3" id="filter_merchant_name" onClick={handleClick}>Merchant name</button>
                <button type="button" className="btn btn-outline-primary btn-lg mx-3" id="filter_updated_name" onClick={handleClick}>Updated time</button>
            {/*<select className="form-select" aria-label="Default select example"*/}
            {/*        onChange={(event) => setFilter(event.target.value)}>*/}
            {/*    <option selected>Open this select menu</option>*/}
            {/*    <option value="id">ID</option>*/}
            {/*    <option value="status">Status</option>*/}
            {/*    <option value="customer_name">Customer name</option>*/}
            {/*    <option value="merchant_name">Merchant name</option>*/}
            {/*    <option value="updated_time">Updated time</option>*/}
            {/*</select>*/}
            {/*    <select className="form-select" id="floatingSelect" aria-label="Floating label select example">*/}
            {/*        <option selected>Open this select menu</option>*/}
            {/*        <option value="1">One</option>*/}
            {/*        <option value="2">Two</option>*/}
            {/*        <option value="3">Three</option>*/}
            {/*    </select>*/}
            {/*    <label htmlFor="floatingSelect">Works with selects</label>*/}
            </div>

        </div>
    )
}
export default Filter
